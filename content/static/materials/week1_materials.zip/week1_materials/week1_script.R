# Data Viz in R
# 2021-10-05
# Getting Started in R


# ..................................................
# Notes ----
# Text with a "#" in front of it are called comments.
# Keyboard shortcuts
#  To generate the assignment operator, <-, type Alt - (Win/Linux) or Option - (Mac) 
#  To submit a line of R code from a script, place the cursor in the line and hit Ctrl + Enter (Win/Linux) or Cmd + Return (Mac)
#  To submit many lines of R code from a script, highlight the lines and hit Ctrl + Enter (Win/Linux) or Cmd + Return (Mac).


# ..................................................
# Load libraries ----
library(tidyverse)


# ..................................................
# Load and inspect data ----
# You can import pretty much any data into R: Excel, Stata, SPSS, SAS, 
# CSV, JSON, fixed-width, TXT, DAT, shape files, etc. 
property <- read_csv("parcels_cards_chacteristics.csv")

# multiple ways of looking at the ata
names(property)
glimpse(property)
head(property)
table(property$cardtype) # base R functions 
# In most  base R functions you need to refer to variables with $.
# The tidyverse uses "data-masking" so doesn't require the $


# ..................................................
# dplyr verbs, isolating ----
# count
# How many properties in each county voting district?
count(property, magisterialdistrict)

# How many properties are assigned eah condition value?


# select
# Select the yearbuilt column
select(property, yearbuilt)

# Select the variables related to heating and cooling


# filter
# Find all properties built in 2020
filter(property, yearbuilt == "2020")

# Find all residential properties built in 2020


# arrange
# Sort properties by year built 
arrange(property, yearbuilt)
arrange(property, desc(yearbuilt))

# Sort properties by total value



# ..................................................
# pipes ----
# nesting functions
# filter for residential properties built in 2020 AND 
#   select total value and size AND
#   sort in descending order of value
arrange(
  select(
    filter(property, yearbuilt == "2020" & cardtype == "R"), 
    totalvalue, finsqft), 
  desc(totalvalue))

# saving intermediate steps
tmp <- filter(property, yearbuilt == "2020" & cardtype == "R")
tmp <- select(tmp, totalvalue, finsqft)
arrange(tmp, desc(totalvalue))

# using the pipe
property %>% 
  filter(yearbuilt == "2020" & cardtype == "R") %>% 
  select(totalvalue, finsqft) %>% 
  arrange(desc(totalvalue))


# ..................................................
# dplyr verbs, deriving ----
# summarize
# What is the size of the smallest residential property built in 2020?
# What is the size of the largest residential property built in 2020?
# How many properties were built in 2020
property %>% 
  filter(yearbuilt == "2020" & cardtype == "R") %>% 
  summarize(smallest = min(finsqft), 
            biggest = max(finsqft), 
            total = n())

# What's the most highly assessed residential property built in 2020?
# What's the least highly assessed residentia property built in 2020?


# group_by
# What is the smallest and largest residential property in 2020 by magisterial district?
# How many residential properties were built in 2020 in each district?
# What is the average assessed value by district?
# Sort the districts by average value of 2020 properties.
property %>% 
  filter(yearbuilt == "2020" & cardtype == "R") %>% 
  group_by(magisterialdistrict) %>% 
  summarize(smallest = min(finsqft), 
            biggest = max(finsqft),
            number = n(),
            avg_value = mean(totalvalue, na.rm = TRUE)) %>% 
  arrange(desc(avg_value))

# mutate
# Let's fix the square feet variable, telling R to treat it as a number,
#   then calculate the value/square foot,
#   and then answer the question above again (adding the average value/sqft)
property %>% 
  filter(yearbuilt == "2020" & cardtype == "R") %>% 
  mutate(finsqft = as.numeric(finsqft),
         value_sqft = totalvalue/finsqft) %>% 
  group_by(magisterialdistrict) %>% 
  summarize(smallest = min(finsqft), 
            biggest = max(finsqft),
            number = n(),
            avg_value = mean(totalvalue, na.rm = TRUE),
            avg_value_sqft = mean(value_sqft)) %>% 
  arrange(desc(avg_value))

# Let's create a dataframe with the median sale price by the year of sale
#   (and number of sales) among residential properties.
# We need to make lastsaleprice numeric and 
#   extract the year from lastsaledate1 (and make it numeric)
# Then we'll filter for residential properties
#   and remove observations with sale prices of 0
# Then group and summarize



# ..................................................
# Factors ----
property %>% count(condition) # currently a character

property %>% 
  mutate(condition = factor(condition)) %>% # make a factor
  count(condition)

# assert the ordering of the factor levels
cond_levels <- c("Excellent", "Good", "Average", "Fair", "Poor", "Very Poor", "Unknown")
property %>% 
  mutate(condition = factor(condition, levels = cond_levels)) %>% 
  count(condition)

# forcats
property %>% 
  mutate(condition = fct_infreq(condition)) %>% 
  count(condition)

property %>% 
  mutate(condition = fct_lump(condition, n = 6)) %>% 
  count(condition)


# ..................................................
# ggplot2 ----
# scatterplot example
# Does the size of the house change as a function of the year built?
ggplot(property, aes(x = as.numeric(yearbuilt), y = as.numeric(finsqft))) +
  geom_point()

# filter for residential properties
# map magisterial district to the color aesthetic
# add transparency to the points
# facet by magisterial district instead


# line example
# How many residential properties were built each year?
property %>% 
  filter(cardtype == "R") %>% 
  group_by(year = as.numeric(yearbuilt)) %>% 
  summarize(total = n()) %>% 
  ggplot(aes(x = year, y = total)) +
  geom_line()

# Use the property sale price year data frame we created earlier
#   to graph the median sale price by year of sale
#   (filter to 1983-2020)


# bar example
# How many residential properties in each magisterial district?
property %>% 
  filter(cardtype == "R") %>% 
  ggplot(aes(x = magisterialdistrict)) +
  geom_bar()

# order the district factors by frequency
# change the color of the bars
# create era as an ordered factor and add it as a fill aesthetic

