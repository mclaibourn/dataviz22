# Data Viz in R
# 2022-09-28
# Practicing with R


# ..................................................
# Load libraries and data ----
## Libraries

library(tidyverse)
library(tigris)
library(ggthemes)
library(patchwork)

library(knitr)
library(kableExtra)
library(DT)


## Data
# gag law data from last week
gag <- read_csv("data/gaglaws.csv")

# Pull states from US CENSUS/tigris instead
states <- states(cb = TRUE) # cb = TRUE generates a smaller/more approximate shapefile
st_crs(states) # NAD83


# ..................................................
# Prep data ----
## gag law data ----

# Fix dates
gag <- gag %>% 
  mutate(Date = str_extract(`Date Introduced`, "\\d+/\\d+/\\d+"), # extract just date part
         Date = as.Date(Date, "%m/%d/%Y"))

# Collapse targets:
# K-12, colleges, university
# state agencies, state institutions, state entities, state contractors, political subdivisions,
# non-profits, tax exempt organizations, employers
gag <- gag %>% 
  mutate(target_k12 = str_detect(`Explicitly Targets`, "K-12"),
         target_college = str_detect(`Explicitly Targets`, "colleges|university"),
         target_stateorg = str_detect(`Explicitly Targets`, "state|political"),
         target_other = str_detect(`Explicitly Targets`, "employers|tax|non-profits"))

# pivot to long
gag_long <- gag %>% 
  select(State, Date, target_k12:target_other) %>% 
  pivot_longer(!c(State, Date), 
               names_to = "target_type", 
               values_to = "targeted",
               names_prefix = "target_")

## spatial data ----
not48 <- c("02", "15", "60", "66", "69", "72", "78")

states48 <- states %>% 
  filter(!(GEOID %in% not48))


# ..................................................
# Save data ----
saveRDS(gag, "data/gaglaws.RDS")
saveRDS(gag_long, "data/gaglaws_long.RDS")
saveRDS(states48, "data/state_shapefile.RDS")

# gag <- readRDS("data/gaglaws.RDS")
# gag_long <- readRDS("data/gaglaws_long.RDS")
# states48 <- readRDS("data/state_shapefile.RDS")


# ..................................................
# Themes ----

# create state-level gag order df
gag_state <- gag %>% 
  group_by(State) %>% 
  summarize(numbills = sum(target_k12)) 

# Initial figure
ggplot(gag_state, aes(y = fct_reorder(State, numbills), x = numbills)) +
  geom_col() +
  labs(x = "", y = "", title = "Gag Laws Targeting K-12 Education") 

# Changing theme (and adding color)
ggplot(gag_state, aes(y = fct_reorder(State, numbills), x = numbills)) +
  geom_col(fill = "slategray3") +
  labs(x = "", y = "", title = "Gag Laws Targeting K-12 Education") +
  theme_few() + # theme_minimal 
  theme(axis.text.y = element_text(size = 8))


# ..................................................
# Annotation ----

n_distinct(gag$State) # value for annotation

ggplot(gag_state, aes(y = fct_reorder(State, numbills), x = numbills)) +
  geom_col(fill = "slategray4") +
  labs(x = "", y = "", title = "") +
  annotate("text", x = 15, y = 15, color = "slategray",
           label = "42 states had at least one bill\n introduced to limit teaching\n in K-12 schools in 2021-2022") +
  theme_few() +  
  theme(axis.text.y = element_text(size = 8))


# initial map
# join gag_state to states
gag_state_sf <- left_join(states48, gag_state,
                          by = c("NAME" = "State"))  

gag_state_sf <- gag_state_sf %>% 
  mutate(numbills = replace_na(numbills, 0))

ggplot(gag_state_sf) +
  geom_sf(aes(fill = numbills)) +
  scale_fill_viridis_c(option = "plasma", name = "# Bills")

# needs to better differentiate the 0s, will make breaks
ggplot(gag_state_sf, aes(x = numbills)) + geom_histogram()
# 0, 1-2, 3-5, 6-9, 10-14, 15-25
gag_state_sf <- gag_state_sf %>% 
  mutate(binbills = cut(numbills, right = FALSE,
                        breaks = c(0, 1, 3, 6, 10, 15, 25),
                        labels = c("0", "1-2", "3-5", "6-9",
                                   "10-14", "15-25"),
                        ordered_result = TRUE)) 

count(gag_state_sf, binbills)

ggplot(gag_state_sf) +
  geom_sf(aes(fill = binbills)) +
  scale_fill_viridis_d(option = "plasma", name = "# Bills") +
  theme_void()


# ..................................................
# Combining Plots ----
# patchwork

# go back and save the figures above as bar and map
bar + map +
  plot_annotation(title = "Number of Gag Bills Targeting K-12 Education",
                  caption = "Data collected by PEN America: https://pen.org/report/americas-censored-classrooms/")

# map / bar +
#   plot_annotation(title = "Number of Gag Bills Targeting K-12 Education",
#                   caption = "Data collected by PEN America: https://pen.org/report/americas-censored-classrooms/")


# ..................................................
# Tables: kable  ----

gag_state

gag_state %>% 
  kbl()

# add styling: defaults to bootstrap theme
gag_state %>% 
  kbl(align = "c") %>%
  kable_styling(bootstrap_options = c("striped", "hover"))

# change theme
gag_state %>% 
  kbl(align = "c") %>%
  kable_paper("hover", full_width = F)

# boostrap_options include: striped, hover, condensed, responsive
# Other options: full_width, position, font_size, etc.

# scrolling
gag_state %>% 
  kbl(align = "c") %>% 
  kable_styling(bootstrap_options = c("striped", "hover")) %>% 
  scroll_box(height = "300px")


# ..................................................
# Tables: DT  ----

# Default
gag %>% 
  select(State:`Primary Sponsor`) %>% 
  datatable()

# Change column names, add a caption
gag %>% 
  select(c(1:5, 7,8)) %>% 
  datatable(
          colnames = c('State', 'Bill Number', 'Date', 'Status', 'Sponsor', 'Targets', 'Enforcement'),
          caption = 'Data collected by PEN America: https://pen.org/report/americas-censored-classrooms/')

# Make columns individually filterable, change pagelength
gag %>% 
  select(c(1:5, 7,8)) %>% 
  datatable(filter = 'top', options = list(pageLength = 5),
    colnames = c('State', 'Bill Number', 'Date', 'Status', 'Sponsor', 'Targets', 'Enforcement'),
    caption = 'Data collected by PEN America: https://pen.org/report/americas-censored-classrooms/')


# ..................................................
# Projects ----
# zipped folder with
#   original data, unless downloaded within the script
#   cleaning script to generate .RDS (an .R script)
#   the cleaned/prepped data (an .RDS file)
#   the markdown file that generates, contains narrative (an .Rmd file)
#   the knitted/rendered file (an .html file)
