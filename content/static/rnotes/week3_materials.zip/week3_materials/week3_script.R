# Data Viz in R
# 2022-09-07
# Practicing with R

# To use the tidycensus package you need a census api key
#   http://api.census.gov/data/key_signup.html

# Then you need to set your census api key
# census_api_key("YOUR API KEY GOES HERE", install = TRUE)
#   install = TRUE will add the key to your .Renviron for future use

# Learn more about tidycensus
#   https://walker-data.com/tidycensus/index.html


# ..................................................
# Load libraries and data ----
# Libraries
library(tidyverse)
library(tidycensus)
# census_api_key("YOUR API KEY GOES HERE", install = TRUE)
library(ggforce) # for sina
library(treemapify) # for tree plot
library(waffle) # for wafflet plot
library(GGally) # for ggpairs/ggcorr

# For color stuff
library(scales) 
library(RColorBrewer)
library(viridis)
library(rcartocolor)
library(wesanderson)
library(ghibli)

# Data
property <- read_csv("data/parcels_cards_chacteristics.csv")
tractnames <- read_csv("data/tractnames.csv")


# ..................................................
# From week 2 ----
## Amounts ----
# Grouped bars
# Create era built factor, value_sqft from last week
property <- property %>% 
  mutate(value_sqft = totalvalue/finsqft,
         era = case_when(
           yearbuilt < 1950 ~ "Pre-1950",
           yearbuilt >= 1950 & yearbuilt < 2000 ~ "1950-1999",
           yearbuilt >= 2000 ~ "Post-2000"),
         era = factor(era, levels = c("Pre-1950", "1950-1999", "Post-2000"))
  )

# use era built as fill factor
property %>% 
  filter(magisterialdistrict != "Unassigned") %>%
  ggplot(aes(x = fct_infreq(magisterialdistrict), fill = era)) +
  geom_bar(position = "dodge") 

# To try:
# group districts within eras instead
# instead of grouping, try faceting


# Dot plots (or lollipops)

# find median value per square foot in county
medvalue <- property %>% 
  filter(!esdistrict %in% c("NULL", "Unassigned", "Yancey"),
         !is.na(esdistrict)) %>% 
  summarize(med_value_sqft = median(value_sqft, na.rm = TRUE)) %>% 
  as_vector()

# make property by elementary district data frame
prop_by_esdistrict <- property %>% 
  filter(!esdistrict %in% c("NULL", "Unassigned", "Yancey"),
         !is.na(esdistrict)) %>% 
  group_by(esdistrict) %>% 
  summarize(med_value_sqft = median(value_sqft, na.rm = TRUE)) %>%
  # add variable for whether district median is above or below county median
  mutate(hi_lo = ifelse(med_value_sqft < medvalue, "Low", "High"))

# dot plot
prop_by_esdistrict %>% 
  ggplot(aes(x = med_value_sqft, 
             y = fct_reorder(esdistrict, med_value_sqft))) + 
  geom_point(size = 5, color = "#0072B2") +  
  labs(title = "Does Assessed Value per Square Footage of Homes Vary by School District?",
       subtitle = "Median Assesed Value/Square Foot by Elementary School Zones", 
       x = "Median Assessed Value per Square Foot",
       y = "") +
  theme_minimal()

# lollipop version
prop_by_esdistrict %>% 
  ggplot(aes(x = med_value_sqft, 
             y = fct_reorder(esdistrict, med_value_sqft))) + 
  geom_point(size = 5, color = "#0072B2") +  
  geom_segment(aes(x=0, xend=med_value_sqft, y=esdistrict, yend=esdistrict), 
               color = "grey") + 
  labs(title = "Does Assessed Value per Square Footage of Homes Vary by School District?",
       subtitle = "Median Assesed Value/Square Foot by Elementary School Zones", 
       x = "Median Assessed Value per Square Foot",
       y = "") +
  theme_minimal()

# To try:
# adjust the line segment to reflect deviation
# add reference line for median value 
# color by hi_lo 


## Proportions ----

# Pie charts and donuts -- though you probably shouldn't

# Map use codes to residence type
count(property, usecode) %>% View()

sfh <- c("Single Family", "Single Family-Rental")
mfh <- c("3-4 Family", "Apartment", "Apartments",
         "Condo-Res-TH", "Condo-Res-Garden", 
         "Duplex", "Doublewide", "Mobile Home", 
         "Multi-Family", "Small Apartment")
vac <- c("Vacant (R5-R6)", "Vacant Residential Land")

# Pie and Donut data prep
prop_pie <- property %>% 
  mutate(use = case_when(
    usecode %in% sfh ~ "single-family",
    usecode %in% mfh ~ "multi-family",
    usecode %in% vac ~ "vacant-land",
    TRUE ~ "non-residence"
  ),
  use = factor(use, levels = c("single-family", 
                               "multi-family", 
                               "vacant-land", 
                               "non-residence"))
  ) %>% 
  filter(!use == "non-residence") %>% 
  group_by(use) %>% 
  summarize(num = n())  %>% 
  arrange(num) %>% 
  # this sorts the data in the order I want it to plot
  mutate(prop = num/sum(num) * 100,
         # calculate the percent within each type
         ypos = cumsum(prop) - 0.5*prop,
         # calculate point for label position
         label = ifelse(prop > 5, as.character(use), NA_character_)
         # don't print labels if value is really small
  )

# Pie 
ggplot(prop_pie, aes(x = 1, y = prop, fill = use)) + 
  geom_col(color = "white") + 
  coord_polar(theta = "y") +
  geom_text(aes(y = ypos, x = 1.25, label = label), 
            color = "white", size=4) +
  guides(fill = "none") +
  theme_void()


# Donut
ggplot(prop_pie, aes(x = 2, y = prop, fill = use)) + 
  geom_col(color = "white") + 
  coord_polar(theta = "y") +
  geom_text(aes(y = ypos, x = 2, label = label), 
            color = "white", size=4) +
  guides(fill = "none") +
  xlim(0.5, 2.5) +
  theme_void()


# Tree map
acreage <- property %>% 
  group_by(magisterialdistrict) %>% 
  summarize(acres = sum(lotsize)) %>% 
  mutate(label = paste(magisterialdistrict, scales::comma(acres), "acres", sep = "\n"))

ggplot(acreage, aes(area = acres, fill = acres, 
                    label = label)) +
  geom_treemap() + 
  geom_treemap_text(colour = "white") +
  labs(title = "Residential Acreage by Magisterial District") +
  theme(legend.position = "none")


# Waffles
# https://github.com/hrbrmstr/waffle
(prop_waffle <- prop_pie %>% 
    mutate(num_scaled = round(num/100)) %>% 
    select(use, num_scaled) %>% 
    droplevels())

# using geom_waffle 
ggplot(prop_waffle, aes(fill = use, values = num_scaled)) +
  geom_waffle(n_rows = 10, color = "white", flip = TRUE) +
  coord_equal() +
  scale_fill_manual(values = c("#969696", "#009bda", "#c7d4b6", "#97b5cf"),
                    name = "") +
  theme_void() +
  theme(legend.position = "bottom") 


# ..................................................
# Pull American Community Survey data ----
# B25003 Tenure (number of owning and renting households by tract)
# From data.census.gov: https://data.census.gov/cedsci/table?q=b25003&g=0500000US51003%241400000&tid=ACSDT5Y2019.B25003&hidePreview=true

tenure <- get_acs(geography = "tract",
                  table = "B25003",
                  survey = "acs5",
                  year = 2020,
                  state = 51,
                  county = 003,
                  output = "wide")

# or load from the data folder
# tenure <- readRDS("data/tenure.RDS")

# rename vars and generate proportion of owning households
tenure <- tenure %>% 
  rename(totalhh = B25003_001E,
         ownerhh = B25003_002E,
         renterhh = B25003_003E,
         totalhh_moe = B25003_001M,
         ownerhh_moe = B25003_002M,
         renterhh_moe = B25003_003M) %>% 
  mutate(prop_owner = ownerhh/totalhh,
         prop_owner_moe = moe_prop(ownerhh, totalhh, ownerhh_moe, totalhh_moe),
         prop_owner_high = ifelse(prop_owner > median(prop_owner), "GE 70%", "LT 70%"))

# graph: dotplot
ggplot(tenure, aes(x = ownerhh, y = fct_reorder(GEOID, ownerhh))) +
  geom_point() +
  labs(y = "", x = "Owner-occupied housing")


# ..................................................
# Separate (Unite)  ----

tenure <- tenure %>% 
  separate(NAME, into = c("tract", "county", "state"),
           sep = ",")

# graph: dotplot
ggplot(tenure, aes(x = ownerhh, y = fct_reorder(tract, ownerhh))) +
  geom_point() +
  labs(y = "", x = "Owner-occupied housing")


# ..................................................
# Join  ----

# tractnames to tenure
head(tenure$GEOID)
str(tenure$GEOID)
head(tractnames$GEOID)
str(tractnames$GEOID)

tractnames <- tractnames %>% 
  mutate(GEOID = as.character(GEOID))

tenure <- tenure %>% 
  left_join(tractnames)

ggplot(tenure, aes(x = ownerhh, y = fct_reorder(tractnames, ownerhh))) +
  geom_point() +
  labs(y = "", x = "Owner-occupied housing")

# tenure to property
head(property$fips_tract)
str(property$fips_tract)

property <- property %>% 
  mutate(fips_tract = as.character(fips_tract))

property_join <- property %>% 
  left_join(tenure, by = c("fips_tract" = "GEOID"))


# ..................................................
# Scatterplots  ----
# scatter plot: assessed vs sale  price?
property %>% 
  filter(last_sale_year == "2021",
         lastsaleprice > 0) %>% 
  ggplot(aes(x = lastsaleprice, y = totalvalue)) +
  geom_point() 

# add geom_abline(intercept = 0, slope = 1)
# add geom_smooth() # try method = "lm"; method = "gam"


# scatter: add color aesthetic 
property %>% 
  filter(last_sale_year == "2021",
         lastsaleprice > 0 & lastsaleprice < 5e+06,
         hsdistrict != "Unassigned") %>% 
  ggplot(aes(x = lastsaleprice, y = totalvalue, 
             color = hsdistrict)) +
  geom_point() 

# add shape aesthetic for hs
# add geom_smooth()
# add facet_wrap() for hs


# scatter with scaled size/bubble
property %>% 
  filter(last_sale_year == "2021",
         lastsaleprice > 0 & lastsaleprice < 5e+06,
         hsdistrict != "Unassigned") %>% 
  ggplot(aes(x = lastsaleprice, y = totalvalue, 
             color = hsdistrict, size = lotsize)) +
  geom_point(pch = 21) 

# remove size legend
# remove color legend
# add facet_wrap(~ hsdistrict, ncol = 1)


# ..................................................
# Scatterplot Matrices/Correlograms ----
# ggpairs
# https://ggobi.github.io/ggally/articles/ggpairs.html
property %>% 
  filter(last_sale_year == "2021",
         lastsaleprice > 0 & lastsaleprice < 5e+06) %>% 
  select(finsqft, lotsize, totalrooms, lastsaleprice, landvalue, improvementsvalue, hsdistrict) %>% 
  ggpairs()

# map color = hsdistrict

# ggcorr
# https://briatte.github.io/ggcorr/
property %>% 
  filter(last_sale_year == "2021",
         lastsaleprice > 0 & lastsaleprice < 5e+06) %>% 
  select(finsqft, lotsize, totalrooms, lastsaleprice, landvalue, improvementsvalue) %>% 
  ggcorr()

# try geom = "circle", max_size = 10
# try label = TRUE, label_alpha = TRUE


# ..................................................
# Slope graphs/Dumbbell Plots ----
# median sale vs median assessed by tract

# need long data frame for slope graph and dumbbell plot: 
#   tract, type (assessed/sale), median value
tract_sell_assess <- property %>% 
  filter(last_sale_year == "2021",
         lastsaleprice > 0 & lastsaleprice < 5e+06) %>% 
  group_by(fips_tract) %>% 
  summarize(median_assessed = median(totalvalue),
            median_sale = median(lastsaleprice)) %>% 
  pivot_longer(-c(fips_tract), names_to = "value_type", values_to = "value",
               names_prefix = "median_")

# Slope graph: change/difference is conveyed by slope
# Basic plot
ggplot(tract_sell_assess, aes(x = value_type, y = value)) +
  geom_line(aes(group = fips_tract), color = "gray60") +
  geom_point(color = "#0072B2")

# Fancy it up
# Make label df to identify tracts with big differences
tract_labels <- tract_sell_assess %>% 
  group_by(fips_tract) %>% 
  mutate(diff = value - lag(value)) %>% 
  filter(value_type == "sale",
         diff > 50000)

ggplot(tract_sell_assess, aes(x = value_type, y = value)) +
  geom_line(aes(group = fips_tract), color = "gray60") +
  geom_point(color = "#0072B2") +
  geom_text(data = tract_labels,
            aes(x = value_type, y = value, label = fips_tract),
            nudge_x = 0.12, size = 3) +
  guides(color = "none") +
  scale_x_discrete(expand = expansion(add = c(0.05,.25))) +
  scale_y_continuous(breaks = seq(2e+05, 8e+05, 1e+05),
                     labels = paste0(seq(200,800,100), "K")) +
  labs(x = "", y = "Median Home Value",
       title = "Median Assessed Value vs. Median Sale Value",
       subtitle = "By Census Tract, 2021 Sales and Assessments") +
  theme_minimal()

# Could also forgo points and just put values in the figure
# replace geom_point with geom_text


# Dumbbell Plot: change/difference is conveyed by length
# Basic plot
ggplot(tract_sell_assess, aes(x= value, y= fct_reorder(fips_tract, value))) +
  geom_line(aes(group = fips_tract), color = "grey")+
  geom_point(aes(color=value_type)) +
  guides(color = guide_legend("Value")) +
  labs(x = "", y = "",
       title = "Median Assessed Value vs. Median Sale Value",
       subtitle = "By Census Tract, 2021 Sales and Assessments") +
  theme_minimal()

# make value axis labels prettier
# move legend to bottom of figure


# ..................................................
# Colors in R ----

# a function to display a color palette
pal <- function(col, border = "light gray", ...){
  n <- length(col)
  plot(0, 0, type="n", xlim = c(0, 1), ylim = c(0, 1),
       axes = FALSE, xlab = "", ylab = "", ...)
  rect(0:(n-1)/n, 0, 1:n/n, 1, col = col, border = border)
}

# ggplots default palettes: discrete 
# ?scale_color_hue for more about the default discrete palette
pal(hue_pal()(2))
pal(hue_pal()(10))

# ggplots default palettes: continuous
# ?scale_color_gradient for more aboutbthe default continuous palette

# Other palettes
# scale_color_brewer
pal(brewer_pal(palette = "YlGnBu")(5)) # sequential
pal(brewer_pal(palette = "BrBG")(5)) # diverging
pal(brewer_pal(palette = "Set1")(5)) # qualitative
# see https://colorbrewer2.org/ for more

# scale_fill/color_viridis
pal(viridis_pal(option = "viridis")(15)) # sequential
pal(viridis_pal(option = "plasma")(15)) # sequential
# palette options: viridis, magma, inferno, plasma, cividis, rocket, mako, turbo

# scale_fill/color_carto
pal(carto_pal(7, "Sunset")) # sequential
pal(carto_pal(7, "Fall")) # diverging
pal(carto_pal(7, "Vivid")) # qualitative
# use `metacartocolors` to see info about all palettes

# wesanderson: scale_color_manual
pal(wes_palette("Rushmore"))
pal(wes_palette("FantasticFox1"))
pal(wes_palette("Darjeeling1"))
# see https://github.com/karthik/wesanderson

# ghibli: scale_color_ghibli
pal(ghibli_palettes$PonyoMedium)
pal(ghibli_palettes$KikiLight)
pal(ghibli_palettes$TotoroLight)
# see https://ewenme.github.io/ghibli/


# ..................................................
# Using Colors in R ----

# Base plots: color by continuous variable
property %>% 
  filter(totalvalue < 5e+06, 
         esdistrict != "Unassigned") %>% 
  
  ggplot(aes(x = fct_reorder(esdistrict, totalvalue), 
             y = totalvalue, color = totalvalue)) +
  geom_sina(shape = ".") + 
  guides(color = "none") + 
  labs(x = "Elementary School Attendance Zone",
       y = "Total Assessed Value") +
  coord_flip()

# Base plots: color by discrete variable
property %>% 
  filter(totalvalue < 5e+06, 
         magisterialdistrict != "Unassigned") %>% 
  
  ggplot(aes(x = fct_reorder(magisterialdistrict, totalvalue), 
             y = totalvalue, color = magisterialdistrict)) +
  geom_sina(shape = ".") + 
  guides(color = "none") + 
  labs(x = "Magisterial District",
       y = "Total Assessed Value") +
  coord_flip()

## Select colors manually ----
# continuous: scale_fill/color_gradient
property %>% 
  filter(totalvalue < 5e+06, 
         esdistrict != "Unassigned") %>% 
  
  ggplot(aes(x = fct_reorder(esdistrict, totalvalue), 
             y = totalvalue, color = totalvalue)) +
  geom_sina(shape = ".") + 
  scale_color_gradient(low = "#bfd3e6", high = "#4d004b") +
  #scale_color_gradient2(low = "#1d271cff", mid = "#44a57cff", high = "#cec917ff") +
  guides(color = "none") + 
  labs(x = "Elementary School Attensance Zone",
       y = "Total Assessed Value") +
  coord_flip()

# discrete: scale_fill/color_manual
property %>% 
  filter(totalvalue < 5e+06, 
         magisterialdistrict != "Unassigned") %>% 
  
  ggplot(aes(x = fct_reorder(magisterialdistrict, totalvalue), 
             y = totalvalue, 
             color = fct_reorder(magisterialdistrict, totalvalue))) +
  geom_sina(shape = ".") + 
  scale_color_manual(values = rainbow(7)) +
  guides(color = "none") + 
  labs(x = "Magisterial District",
       y = "Total Assessed Value") +
  coord_flip()


## Use RColorBrewer ----
# continuous: scale_fill/color_brewer
property %>% 
  filter(totalvalue < 5e+06, 
         esdistrict != "Unassigned") %>% 
  
  ggplot(aes(x = fct_reorder(esdistrict, totalvalue), 
             y = totalvalue, color = totalvalue)) +
  geom_sina(shape = ".") + 
  #scale_color_brewer(palette = "YlGnBu") + # not enough distinct colors
  scale_color_distiller(palette = "YlGnBu", direction = 1) +
  guides(color = "none") + 
  labs(x = "Elementary School Attensance Zone",
       y = "Total Assessed Value") +
  coord_flip()

# discrete: scale_fill/color_brewer
property %>% 
  filter(totalvalue < 5e+06, 
         magisterialdistrict != "Unassigned") %>% 
  
  ggplot(aes(x = fct_reorder(magisterialdistrict, totalvalue), 
             y = totalvalue, 
             color = fct_reorder(magisterialdistrict, totalvalue))) +
  geom_sina(shape = ".") + 
  scale_color_brewer(palette = "Accent") + 
  guides(color = "none") + 
  labs(x = "Magisterial District",
       y = "Total Assessed Value") +
  coord_flip()

## Use viridis ----
# continuous: scale_fill/color_viridis
property %>% 
  filter(totalvalue < 5e+06, 
         esdistrict != "Unassigned") %>% 
  
  ggplot(aes(x = fct_reorder(esdistrict, totalvalue), 
             y = totalvalue, color = totalvalue)) +
  geom_sina(shape = ".") + 
  scale_color_viridis(option = "plasma", discrete = FALSE) +
  guides(color = "none") + 
  labs(x = "Elementary School Attensance Zone",
       y = "Total Assessed Value") +
  coord_flip()

# discrete: scale_fill/color_viridis
property %>% 
  filter(totalvalue < 5e+06, 
         magisterialdistrict != "Unassigned") %>% 
  
  ggplot(aes(x = fct_reorder(magisterialdistrict, totalvalue), 
             y = totalvalue, 
             color = fct_reorder(magisterialdistrict, totalvalue))) +
  geom_sina(shape = ".") + 
  scale_color_viridis(option = "magma", discrete = TRUE) +
  guides(color = "none") + 
  labs(x = "Magisterial District",
       y = "Total Assessed Value") +
  coord_flip()


## Use rcartocolor ----
# continuous: scale_fill/color_carto_c
property %>% 
  filter(totalvalue < 5e+06, 
         esdistrict != "Unassigned") %>% 
  
  ggplot(aes(x = fct_reorder(esdistrict, totalvalue), 
             y = totalvalue, color = totalvalue)) +
  geom_sina(shape = ".") + 
  scale_color_carto_c(palette = "Teal") +
  guides(color = "none") + 
  labs(x = "Elementary School Attensance Zone",
       y = "Total Assessed Value") +
  coord_flip()

# discrete: scale_fill/color_carto_d
property %>% 
  filter(totalvalue < 5e+06, 
         magisterialdistrict != "Unassigned") %>% 
  
  ggplot(aes(x = fct_reorder(magisterialdistrict, totalvalue), 
             y = totalvalue, 
             color = fct_reorder(magisterialdistrict, totalvalue))) +
  geom_sina(shape = ".") + 
  scale_color_carto_d(palette = "Vivid") + 
  guides(color = "none") + 
  labs(x = "Magisterial District",
       y = "Total Assessed Value") +
  coord_flip()


## Use fun palettes ----
# discrete: wesanderson
property %>% 
  filter(totalvalue < 5e+06, 
         magisterialdistrict != "Unassigned") %>% 
  
  ggplot(aes(x = fct_reorder(magisterialdistrict, totalvalue), 
             y = totalvalue, 
             color = fct_reorder(magisterialdistrict, totalvalue))) +
  geom_sina(shape = ".") + 
  scale_color_manual(values = wes_palette("BottleRocket1")) +
  # several of the palettes have too few color values;
  # to use them, we have to augment the palette like so:
  #scale_color_manual(values = colorRampPalette(wes_palette("FantasticFox1"))(6)) +
  guides(color = "none") + 
  labs(x = "Magisterial District",
       y = "Total Assessed Value") +
  coord_flip()

# discrete: scale_fill/color_ghibli_d
property %>% 
  filter(totalvalue < 5e+06, 
         magisterialdistrict != "Unassigned") %>% 
  
  ggplot(aes(x = fct_reorder(magisterialdistrict, totalvalue), 
             y = totalvalue, 
             color = fct_reorder(magisterialdistrict, totalvalue))) +
  geom_sina(shape = ".") + 
  scale_color_ghibli_d(name = "MononokeLight") + # PonyoMedium
  guides(color = "none") + 
  labs(x = "Magisterial District",
       y = "Total Assessed Value") +
  coord_flip()

# continuous: scale_fill/color_ghibli_c
property %>% 
  filter(totalvalue < 5e+06, 
         esdistrict != "Unassigned") %>% 
  
  ggplot(aes(x = fct_reorder(esdistrict, totalvalue), 
             y = totalvalue, color = totalvalue)) +
  geom_sina(shape = ".") + 
  scale_color_ghibli_c(name = "PonyoLight", direction = -1) + # MarnieMedium
  guides(color = "none") + 
  labs(x = "Elementary School Attensance Zone",
       y = "Total Assessed Value") +
  coord_flip()
