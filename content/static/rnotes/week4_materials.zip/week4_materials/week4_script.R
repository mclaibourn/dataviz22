# Data Viz in R
# 2022-09-13
# Practicing with R

# ..................................................
# Setup ----

## LIBRARIES ----
# Libraries
library(tidyverse)
library(readxl)
library(scales)
# library(googlesheets4)

# # For color stuff
library(rcartocolor)
library(viridis)
library(ghibli)
library(wesanderson)

# For spatial stuff
library(sf) # the primary spatial package for today
library(rnaturalearth) # quick access to a world map (also states)
library(rnaturalearthdata) # and some data points about countries
library(tigris) # to call Census boundary files
library(leaflet) # for leaflet

options(tigris_use_cache = TRUE) # cache shapefiles so you don't have to keep downloading them
theme_set(theme_bw()) # globally change the ggplot theme


## DATA ----
# Data from rnaturalearth/rnaturalearthdata
world <- ne_countries(scale = "medium", returnclass = "sf")
usstates <- ne_states(iso_a2 = "US", returnclass = "sf")

# Data from https://edits.nationalmap.gov/apps/gaz-domestic/public/all-official-sq-names
# as part of https://www.doi.gov/pressreleases/interior-department-completes-removal-sq-federal-use
renamed <- read_excel("data/interior_names.xlsx")
renamed_sf <- st_as_sf(renamed, coords = c("Longitude", "Latitude"),  crs = 4269)

# Albemarle County property data
property <- read_csv("data/parcels_cards_chacteristics.csv")



# ..................................................
# Tidy Data ----
## EXAMPLE 1 ----
# reading in a non-tidy spreadsheet

# read in first columns: occupation and numbers across years
hcnums <- read_excel("data/hcempl.xlsx", range = "A5:H49") %>%
  rename(occupation = "Occupation title") %>% 
  # remove rows designating occupation type: practitioner or support position
  filter(!occupation %in% c("Health care practitioners and technical occupations",
                            "Health care support occupations")) %>% 
  # change year columns to numbers, add indicator for occupation type
  mutate(across(`2000`:`2020`, as.numeric),
         prac_supp = rep(c("practitioner", "support"), times = c(28, 14)))

# pivot the table to make it long
hcnums_long <- hcnums %>% 
  pivot_longer(cols = !c(occupation, prac_supp), names_to = "year", values_to = "number")

# read in second columns: median wages across years
hcwages <- read_excel("data/hcempl.xlsx", range = c("I5:O49")) %>% 
  # remove rows designating occupation type: practitioner or support position
  filter(!is.na(`2020`)) %>% 
  # change year columns to numbers
  mutate(across(`2000`:`2020`, as.numeric))

# pivot the table to make it long
hcwages_long <- hcwages %>% 
  pivot_longer(cols = `2000`:`2020`, names_to = "year", values_to = "medwage")

# combine data frames -- can't join, but can bind
df <- bind_cols(hcnums_long, hcwages_long) %>% 
  select(occupation, prac_supp, year = year...3, number, medwage) %>% 
  # fix year again
  mutate(year = as.numeric(year)) %>% 
  # remove footnote characters from occupation titles
  mutate(occupation = str_remove(occupation, "\\d"),
         occupation = str_remove(occupation, "\\\\"))

# graph something...
ggplot(df, aes(x = year, y = number)) +
  geom_line(aes(group = occupation)) 
# group aesthetic is often especially useful with longitudinal (e.g., time-series, cross-section) data

# save the work to read in for later analysis/visualization
# saveRDS(df, "data/health_occupation_wages.RDS")


## EXAMPLE 2 ----
# reading in a semi-tidy googlesheet
# from this initiative https://pen.org/report/educational-gag-orders/

# gag <- read_sheet("https://docs.google.com/spreadsheets/d/1Tj5WQVBmB6SQg-zP_M8uZsQQGH09TxmBY73v23zpyr0/edit#gid=107383712",
#                   sheet = 4,
#                   col_types = "c")
# write_csv(gag, "data/gaglaws.csv")

gag <- read_csv("data/gaglaws.csv")

# Fix dates
gag <- gag %>% 
  mutate(Date = str_extract(`Date Introduced`, "\\d+/\\d+/\\d+"), # extract just date part
         Date = as.Date(Date, "%m/%d/%Y"))

# Collapse targets:
# K-12, colleges, university
# state agencies, state institutions, state entities, state contractors, political subdivisions,
# non-profits, tax exempt organizations, employers
gag <- gag %>% 
  mutate(target_k12 = str_detect(`Explicitly Targets`, "K-12"),
         target_college = str_detect(`Explicitly Targets`, "colleges|university"),
         target_stateorg = str_detect(`Explicitly Targets`, "state|political"),
         target_other = str_detect(`Explicitly Targets`, "employers|tax|non-profits"))

# visualize targets: pivot to long
gag_long <- gag %>% 
  select(State, Date, target_k12:target_other) %>% 
  pivot_longer(!c(State, Date), 
               names_to = "target_type", 
               values_to = "targeted",
               names_prefix = "target_")

gag_long %>% 
  group_by(target_type) %>% 
  summarize(target_count = sum(targeted),
            target_percent = (target_count/nrow(gag))*100) %>% 
  ggplot(aes(x = target_type, y = target_percent, fill = target_type)) +
  geom_col() +
  scale_fill_manual(values = c("gray50", "red", "gray50", "gray50"),
                    guide = "none") +
  # scale_fill_ghibli_d(name = "YesterdayLight", direction = -1,
  #                     guide = "none") +
  labs(title = "Targets of Educational Gag Order Bills",
       subtitle = "Bills Introduced in 2021-2022 State Legislatures",
       caption = "Data collected by PEN America: https://pen.org/report/americas-censored-classrooms/",
       x = "", y = "Percent of Bills")



# ..................................................
# Mapping the World ----
## MAPPING WITH GGPLOT/SF ----

# just the map
ggplot(data = world) +
  geom_sf()

# We can add line and fill colors
ggplot(data = world) +
  geom_sf(fill = "#669438", color = "#32481B") +
  theme_void()


## PROJECTIONS ----
# Default is the CRS of the data
st_crs(world) # st_crs is from sf

# Robinson
ggplot(data = world) + 
  geom_sf(fill = "#669438", color = "#32481B") +
  coord_sf(crs = "+proj=robin")

# Sinusoidal
ggplot(data = world) + 
  geom_sf(fill = "#669438", color = "#32481B") +
  coord_sf(crs = st_crs("ESRI:54008")) # or use the CRS code

# Mollweide
ggplot(data = world) + 
  geom_sf(fill = "#669438", color = "#32481B") +
  coord_sf(crs = "+proj=moll")


## EXTENT ----
ggplot(data = world) + 
  geom_sf(fill = "#669438", color = "#32481B") +
  coord_sf(xlim = c(-172.54, -47.74), 
           ylim = c(23.81, 86.46))
# lat and lon boundaries given the North America WGS84 CRS
# I had to look these up -- unless you work with GIS data
# regularly, you'd probably need to look these up, too


## COLORS ----
# Color the countries to distinguish adjacent countries 
ggplot(data = world) + 
  geom_sf(aes(fill = as.factor(mapcolor7))) +
  scale_fill_viridis_d(option = "plasma") +
  guides(fill = "none") 
# The Natural Earth dataset comes with columns to assign
# a coloring scheme with 7–13 colors (e.g., mapcolor7) 
# so that no countries with a shared border share a color. 

# Color the countries by an attribute: Choropleths!
ggplot(data = world) + 
  geom_sf(aes(fill = pop_est)) +
  scale_fill_carto_c(palette = "SunsetDark", name = "Population") +
  theme(legend.position = "bottom")

# binning population
world %>% 
  mutate(pop_bins = factor(ntile(pop_est, 5), 
                           labels = c("Q1", "Q2", "Q3", "Q4", "Q5"))) %>% 
  ggplot() + 
  geom_sf(aes(fill = pop_bins)) +
  scale_fill_carto_d(palette = "PurpOr", name = "Population\n (Quintiles)") +
  theme(legend.position = "bottom")

# using an already categorical variable
ggplot(data = world) + 
  geom_sf(aes(fill = income_grp)) +
  scale_fill_viridis_d(option = "viridis", name = "") 



# ..................................................
# Mapping the US ----
## STATES ----

# from rnaturalearth
ggplot(usstates) + 
  geom_sf()

# reduce to lower 48
us48 <- usstates %>% 
  filter(!woe_name %in% c("Alaska", "Hawaii"))

ggplot(us48) + 
  geom_sf(fill = "purple", color = "white") 

# create number of gag bills by state and join to states to make choropleth map
gag_state <- gag %>% 
  group_by(State) %>% 
  summarize(nbills = n())

us48_gaglaws <- us48 %>% 
  select(name, region, postal, fips, latitude, longitude) %>% 
  left_join(gag_state, by = c("name" = "State")) %>% 
  mutate(nbills = ifelse(is.na(nbills), 0, nbills))

ggplot(us48_gaglaws) + 
  geom_sf(aes(fill = nbills)) +
  scale_fill_viridis_c(option = "plasma")

# Pull states from US CENSUS/tigris instead
states <- states(cb = TRUE) # cb = TRUE generates a smaller/more approximate shapefile
st_crs(states) # NAD83

not48 <- c("02", "15", "60", "66", "69", "72", "78")

states48 <- states %>% 
  filter(!(GEOID %in% not48))

ggplot(states48) +
  geom_sf() +
  theme_void()

ggplot(states48) +
  geom_sf() +
  coord_sf(crs = st_crs("EPSG:5070")) +
  theme_void()

# plot DOI renamed sites on top of states
# what is this?
head(renamed_sf)

ggplot(renamed_sf, aes(x = fct_infreq(State))) +
  geom_bar() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  

# I already transformed renamed_sf to have the same CRS as the tigris shapefile
ggplot(states48) +
  geom_sf(fill = ghibli_palettes$TotoroLight[7]) +
  geom_sf(data = filter(renamed_sf, State != "Alaska"), 
          color = ghibli_palettes$TotoroLight[5]) +
  theme_void()


## BONUS: Leaflet version (points) ----
# For interactive online maps
# https://rstudio.github.io/leaflet/

# leaflet uses crs = 4326
renamed_sf4326 <- st_transform(renamed_sf, crs = 4326)

leaflet(renamed_sf4326) %>% 
  addTiles() %>% 
  addCircleMarkers(radius = 1, 
                   label = ~ `New Name`) # adds site name on hover

# Clustering the markers
leaflet(renamed_sf) %>% 
  addTiles() %>% 
  addMarkers(
    clusterOptions = markerClusterOptions(),
    label = ~ `New Name`
  )



# Mapping state/localities ----
## VIRGINIA ----
va <- states48 %>% 
  filter(GEOID == "51")

ggplot(va) +
  geom_sf() +
  theme_void()

# get VA counties
va_counties <- counties(state = 51, cb = TRUE) # tigris again

ggplot() +
  geom_sf(data = va, color = wes_palette("FantasticFox1")[1], size = 3) +
  geom_sf(data = va_counties, fill = wes_palette("FantasticFox1")[3], 
          color = wes_palette("FantasticFox1")[2]) +
  theme_void()


## ALBEMARLE COUNTY ----
albco_tracts <- tracts(state = 51, county = 003, year = 2019, cb = TRUE) # still tigris

ggplot(data = albco_tracts) +
  geom_sf() +
  theme_void()

# Let's summarize house values by tract and join to our spatial data
sfh <- c("Single Family", "Single Family-Rental")
mfh <- c("3-4 Family", "Apartment", "Apartments",
         "Condo-Res-TH", "Condo-Res-Garden", 
         "Duplex", "Doublewide", "Mobile Home", 
         "Multi-Family", "Small Apartment")

property_value_tracts <- property %>% 
  filter(cardtype == "R", # remove commercial
         usecode %in% c(sfh, mfh)) %>% # keep properties that are more clearly homes
  mutate(fips_tract = as.character(fips_tract),
         landvalue = as.numeric(landvalue),
         improvementsvalue = as.numeric(improvementsvalue)) %>% 
  group_by(fips_tract) %>% 
  summarize(median_value = median(totalvalue, na.rm = TRUE),
            median_land_value = median(landvalue, na.rm = TRUE),
            median_imp_value = median(improvementsvalue, na.rm = TRUE)) %>% 
  filter(fips_tract != "51003010903")

albco_tracts <- albco_tracts %>% 
  left_join(property_value_tracts, by = c("GEOID" = "fips_tract"))

# map (with continuous value)
ggplot(data = albco_tracts) +
  geom_sf(aes(fill = median_value)) +
  scale_fill_viridis_c(option = "viridis") +
  theme_void()

# map (with binned values, quartiles)
albco_tracts %>% 
  mutate(median_value_quintiles = factor(ntile(median_value, 4))) %>% 
  ggplot() +
  geom_sf(aes(fill = median_value_quintiles)) +
  scale_fill_viridis_d(option = "viridis", name = "Median\n Property\n Values") +
  theme_void()

# Let's add tract labels at the polygon centroids
tract_points <- st_centroid(albco_tracts)

# the centroids are in the geometry list; we need them as
# latitude and longitude columns for plotting purposes
tract_points <- tract_points %>% 
  mutate(lat = st_coordinates(.)[,1],
         lon = st_coordinates(.)[,2])

albco_tracts %>% 
  mutate(median_value_quintiles = factor(ntile(median_value, 5))) %>% 
  ggplot() +
  geom_sf(aes(fill = median_value_quintiles)) +
  scale_fill_viridis_d(option = "viridis", name = "Median\n Property\n Values") +
  geom_text(data = tract_points, 
            aes(x = lat, y = lon, label = NAME), 
            color = "white", size = 3,
            check_overlap = TRUE) +
  theme_void()


# ..................................................
## BONUS: Leaflet version (CHOROPLETH) ----

# 1. Basic map using Albemarle County Census Tracts

leaflet() %>% 
  addProviderTiles("CartoDB.Positron") %>% 
  addPolygons(data = albco_tracts,
              fillColor = "orange",
              fillOpacity = 0.8,
              weight = 2, 
              opacity = 1,
              color = "white")

albco_tracts <- st_transform(albco_tracts, 4326)

# 2. Map the fill color to median assessed value
# create a palette function

# continuous
pal <- colorNumeric("plasma", domain = albco_tracts$median_value) # viridis

leaflet() %>% 
  addProviderTiles("CartoDB.Positron") %>% 
  addPolygons(data = albco_tracts,
              fillColor = ~pal(median_value),
              fillOpacity = 0.8,
              weight = 2, 
              opacity = 1,
              color = "white")

# binned/percentiles
# pal <- colorQuantile("plasma", domain = albco_tracts$median_value, n = 10)

leaflet() %>% 
  addProviderTiles("CartoDB.Positron") %>% 
  addPolygons(data = albco_tracts,
              fillColor = ~pal(median_value),
              fillOpacity = 0.8,
              weight = 2, 
              opacity = 1,
              color = "white")

# 3. Add a legend

leaflet() %>% 
  addProviderTiles("CartoDB.Positron") %>% 
  addPolygons(data = albco_tracts,
              fillColor = ~pal(median_value),
              fillOpacity = 0.8,
              weight = 2, 
              opacity = 1,
              color = "white") %>% 
  addLegend("bottomright", pal = pal, values = albco_tracts$median_value, 
            title = "Median Assessment", opacity = 0.7)

# 4. Add some hovering functionality

leaflet() %>% 
  addProviderTiles("CartoDB.Positron") %>% 
  addPolygons(data = albco_tracts,
              fillColor = ~pal(median_value),
              fillOpacity = 0.6,
              weight = 1, 
              opacity = 1,
              color = "white",
              highlight = highlightOptions(
                weight = 2,
                fillOpacity = 0.8,
                bringToFront = T)) %>% 
  addLegend("bottomright", pal = pal, values = albco_tracts$median_value, 
            title = "Median Assessment", opacity = 0.7)

# 5. Add some popup information

leaflet() %>% 
  addProviderTiles("CartoDB.Positron") %>% 
  addPolygons(data = albco_tracts,
              fillColor = ~pal(median_value),
              fillOpacity = 0.86,
              weight = 1, 
              opacity = 1,
              color = "white",
              highlight = highlightOptions(
                weight = 2,
                fillOpacity = 0.8,
                bringToFront = T),
              popup = paste0("Tract Number: ", albco_tracts$NAME, "<br>",
                             "Median Value: ", albco_tracts$median_value, 2)) %>% 
  addLegend("bottomright", pal = pal, values = albco_tracts$median_value, 
            title = "Median Assessment", opacity = 0.7)

# 6. Get rid of the NA?
# Only by getting rid of polygon altogether
# also, format popup info

albco_tracts_nouva <- albco_tracts %>% 
  filter(TRACTCE != "010903")

leaflet() %>% 
  addProviderTiles("CartoDB.Positron") %>% 
  addPolygons(data = albco_tracts_nouva,
              fillColor = ~pal(median_value),
              fillOpacity = 0.86,
              weight = 1, 
              opacity = 1,
              color = "white",
              highlight = highlightOptions(
                weight = 2,
                fillOpacity = 0.8,
                bringToFront = T),
              popup = paste0("Tract Number: ", albco_tracts_nouva$NAME, "<br>",
                             "Median Value: ", scales::dollar(albco_tracts_nouva$median_value, 2))) %>% 
  addLegend("bottomright", pal = pal, values = albco_tracts_nouva$median_value, 
            title = "Median Assessment", opacity = 0.7)

